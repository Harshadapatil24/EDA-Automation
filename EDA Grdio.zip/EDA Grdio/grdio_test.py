import gradio as gr

def square(x):
    return x ** 2

interface = gr.Interface(fn = square , inputs = "number",outputs="number")

interface.launch()